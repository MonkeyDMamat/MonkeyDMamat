import streamlit as st 

def main():
    st.set_page_config(page_icon="🌊")
    st.sidebar.success("Select Page Above.")
    st.title("Kontak kami")


if __name__ == '__main__':
    main()
